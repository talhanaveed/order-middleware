import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import AWS from 'aws-sdk';


const dynamo = DynamoDBDocument.from(new DynamoDB());
const TableName = "order";

export const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    var operation;
    var orderid;
    var TaskToken1= "test";
    var payload;
    if(event.Payload)
    {
        operation = event.Payload.detail.operation;
        orderid = event.Payload.detail.payload.orderid;
        if(event.TaskToken)
        {
            TaskToken1 = event.TaskToken;
        }
        payload = 
        {
           "orderid": orderid,
           "taskToken": TaskToken1,
           "status": event.Payload.detail.payload.status
        };
    }
    else if (event.detail)
    {
        operation = event.detail.operation;
        orderid = event.detail.payload.orderid;
        payload=
        {
            "orderid": orderid,
            "status": event.detail.payload.status
        }
    }
    else
    {
        return {
            statusCode: 500,
            body: JSON.stringify('Not a valid operation')
        };
    }

    //payload.TableName = "order";
    console.log('Payload:',payload);

    switch (operation) {
        case 'create':
            {
                const params = {
                    TableName: TableName,
                    Item: payload
                }
                return await dynamo.put(params);
            }
        case 'update':
            {
                const stepfunctions = new AWS.StepFunctions();
                try{
                    const params = {
                        TableName: TableName,
                        Key: {
                            orderid: payload.orderid
                        },
                        UpdateExpression: 'SET #status = :status',
                        ExpressionAttributeNames: {
                            '#status': 'status'
                        },
                        ExpressionAttributeValues: {
                            ':status': payload.status
                        },
                        ReturnValues: 'ALL_NEW'  // Returns the updated item
                    };
                    const result= await dynamo.update(params);

                    const taskToken = (result.Attributes).taskToken;
                    //console.log('Updated item task token:', taskToken);
                    
                    const params2 = {
                        output: "\"Callback task completed successfully.\"",
                        taskToken: taskToken
                    };
            
                    console.log(`Calling Step Functions to complete callback task with params ${JSON.stringify(params2)}`);
                    try{
                        await stepfunctions.sendTaskSuccess(params2).promise();
                    }
                    catch (error) {
                        console.error('Error sending task success:', error);
                        await stepfunctions.sendTaskFailure({
                            taskToken: taskToken,
                            error: "Error",
                            cause: error.message
                        }).promise();
                        return {
                            statusCode: 500,
                            body: JSON.stringify('Error sending task success')
                        };
                    }

                    console.log("Callback sent");
                    return {
                        statusCode: 200,
                        body: JSON.stringify('Task token successfully sent to the state machine')
                    };
                }
                catch (error) {
                    console.error('Error updating item:', error);
                    return {
                        statusCode: 500,
                        body: JSON.stringify('Error updating item')
                    };
                }
            }
        default:
            throw new Error(`Unrecognized operation "${operation}"`);
    }
};

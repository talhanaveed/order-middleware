import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamo = DynamoDBDocument.from(new DynamoDB());
const TableName = "order";

export const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    var orderid;
    var body = event.body;
    orderid = JSON.parse(body).orderid;
    console.log(orderid);

    const params = {
        TableName: TableName,
        Key: 
        {
            "orderid": orderid
        }
    }
    try{
        const result = await dynamo.get(params);
        if (!result.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify('Item not found')
            };
        }
        else
        {
            console.log('Retrieved item:', JSON.stringify(result.Item));
            return {
                statusCode: 200,
                body: JSON.stringify(result.Item)
            };

        }
    }
    catch(error)
    {
        console.error('Error in reading from DynamoDB:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Error reading item from DynamoDB')
        };
        
    }

};
